package client;

/**
 * Launcher for CreateWhiteBoard.
 * Needed for resolving JavaFX runtime issue.
 */
public class CreateWhiteBoardLauncher {
    public static void main(String[] args) {
        client.CreateWhiteBoard.main(args);
    }
}
