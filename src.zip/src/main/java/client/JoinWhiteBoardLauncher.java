package client;

/**
 * Launcher for JoinWhiteBoard.
 * Needed for resolving JavaFX runtime issue.
 */
public class JoinWhiteBoardLauncher {
    public static void main(String[] args) {
        client.JoinWhiteBoard.main(args);
    }
}
